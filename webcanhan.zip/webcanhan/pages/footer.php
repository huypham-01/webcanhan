<div class="clear"></div>
	<!-- Site footer -->
    <footer class="site-footer">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-6" style="max-width: 40%;">
            <h6>Trụ sở</h6>
            <li>Số 8 Tam Bình, Tam phú, TP.Thủ Đức</li>
            <li>Hotline: 0392348011</li>
          </div>

          <div class="col-xs-6 col-md-3"  style="flex: 0 0 30%; max-width: 30%">
            <h6>Điều khoản & chính sách</h6>
            <ul class="footer-links">
              <li><a href="">- Chính sách giao hàng</a></li>
              <li><a href="">- Chính sách tích luỹ điểm</a></li>
              <li><a href="">- Điều khoản và điều kiện</a></li>
              
            </ul>
          </div>

          <div class="col-xs-6 col-md-3" style="flex: 0 0 30%; max-width: 30%">
            <h6>Hỗ trợ khách hàng</h6>
            <ul class="footer-links">
              <li><a href="">- Chính sách bảo mật</a></li>
              <li><a href="">- Chính sách bảo hành đổi trả hàng hóa</a></li>
              <li><a href="x">- Chính sách thanh toán</a></li>
            </ul>
          </div>
        </div>
        <hr>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-6 col-xs-12">
            <p class="copyright-text">Copyright &copy; 2023 Phạm Quang Huy</p>
          </div>

          <div class="col-md-4 col-sm-6 col-xs-12">
            <ul class="social-icons">
              <li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
              <li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>  
            </ul>
          </div>
        </div>
      </div>
	</footer>

