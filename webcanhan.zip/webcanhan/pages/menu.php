<?php

	$sql_danhmuc = "SELECT * FROM tbl_danhmuc ORDER BY id_danhmuc DESC";
	$query_danhmuc = mysqli_query($mysqli,$sql_danhmuc);
	
	    		
?>
<?php
	if(isset($_GET['dangxuat'])&&$_GET['dangxuat']==1){
		unset($_SESSION['dangky']);
	} 
?>
<nav class="navbar navbar-expand-lg navbar-dark " style="width: 100%;height: 46px; background-color: rgb(26 26 26)!important; ">
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php" style="color:white; font-size:20px">Trang chủ <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item"><a class="nav-link" href="index.php?quanly=tintuc" style="color:white; font-size:20px">Tin tức</a></li>
	<li class="nav-item"><a class="nav-link" href="index.php?quanly=lienhe" style="color:white; font-size:20px">Liên hệ</a></li>
	<li class="nav-item" style="color:white; font-size:20px ; margin-top: 8px; margin-left: 6cm;">
	<p>
				<?php
				if(isset($_SESSION['dangky'])){
					echo 'Người dùng: '.'<span style="color:white">'.$_SESSION['dangky'].'</span>';
				
				} 
				?>
				</p>
	</li>

      <!-- <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-expanded="false" >
          Danh mục đồ chơi
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <?php 
				while($row_danhmuc = mysqli_fetch_array($query_danhmuc)){
				?>
          <a class="dropdown-item" href="index.php?quanly=danhmucsanpham&id=<?php echo $row_danhmuc['id_danhmuc'] ?>"><?php echo $row_danhmuc['tendanhmuc'] ?></a>
        <?php
				} 
				?>
        </div>
      </li> -->

      	<?php
				if(isset($_SESSION['dangky'])){ 

				?>
				<li class="nav-item"><a style="color:white; font-size:20px; " class="nav-link" href="index.php?dangxuat=1">Đăng xuất</a></li>
				<li class="nav-item"><a style="color:white; font-size:20px" class="nav-link" href="index.php?quanly=thaydoimatkhau">Thay đổi mật khẩu</a></li>
				 <li class="nav-item"><a style="color:white; font-size:20px" class="nav-link" href="index.php?quanly=lichsudonhang">Lịch sử đơn hàng</a></li>
				<?php
				}else{ 
				?>
				<li class="nav-item" style="padding-left: 13cm" ><a class="nav-link" href="index.php?quanly=dangnhap" style="color:white; font-size:20px">Đăng nhập</a></li>
				<li class="nav-item"><a class="nav-link" href="index.php?quanly=dangky" style="color:white; font-size:20px">Đăng ký</a></li>
				<?php
				} 
				?>

    </ul>
    <form class="form-inline my-2 my-lg-0" action="index.php?quanly=timkiem" method="POST">
      <input class="form-control mr-sm-2" type="search" placeholder="Từ khóa..." aria-label="Search" name="tukhoa">
      <button class="btn btn-outline-success my-2 my-sm-0" style="background-color: black;" name="timkiem" type="submit">Tìm kiếm</button>
    </form>
		<td class="nav-item">
        <a style=" border: 1px solid #000; border-radius: 40px ; background-color: #fff;margin-left: 10px; " class="nav-link" href="index.php?quanly=giohang"><i class="fa fa-shopping-cart" style="font-size:25px;color:blue "><i style="font-size: 25px ">
		<?php
  if(isset($_SESSION['cart'])){
  	$i = 0;
    $demsl = 0;
  	foreach($_SESSION['cart'] as $cart_item){
      $demsl =$i;
  		$i++;
  ?>
  <?php
  	}
  ?>
    <?php echo number_format($i) ?>
  <?php
  } 
  ?></i>
	</i>
	</a>
		
      	</td>
  </div>
</nav>


