       
				<div >
							<h3 style="font-size:20px; font-weight:bold;background:#1c1e1d;color:#fff;height:40px;line-height:37px;text-align:center">Sản phẩm bán chạy</h3>
							
									<?php
									$sql_pro = "SELECT * FROM tbl_sanpham,tbl_danhmuc WHERE tbl_sanpham.id_danhmuc=tbl_danhmuc.id_danhmuc ORDER BY tbl_sanpham.id_sanpham DESC limit 7";
                                    $query_pro = mysqli_query($mysqli,$sql_pro);{
									?>
								<div >
					<?php
					while($row = mysqli_fetch_array($query_pro)){ 
					?>
					<div >
					<div  style="max-width:300px">
						<a href="index.php?quanly=sanpham&id=<?php echo $row['id_sanpham'] ?>">
							<img class="mySlides w3-animate-top" width="100%" src="admincp/modules/quanlysp/uploads/<?php echo $row['hinhanh'] ?>">
							<img class="mySlides w3-animate-bottom" width="100%" src="admincp/modules/quanlysp/uploads/<?php echo $row['hinhanh'] ?>">
							<img class="mySlides w3-animate-top" width="100%" src="admincp/modules/quanlysp/uploads/<?php echo $row['hinhanh'] ?>">
							<img class="mySlides w3-animate-bottom" width="100%" src="admincp/modules/quanlysp/uploads/<?php echo $row['hinhanh'] ?>">
						</a>
					</div>
					</div>
					<script>
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    
  x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 3500);    
}
</script>

					<?php
					} 
					?>
				</div>
										
									<?php
									} 
									?>
									
									
								</div>
							</div>
						</div>
				
                










