-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost
-- Thời gian đã tạo: Th4 15, 2023 lúc 01:13 PM
-- Phiên bản máy phục vụ: 10.4.19-MariaDB
-- Phiên bản PHP: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `web_moi`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `admin_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `tbl_admin`
--

INSERT INTO `tbl_admin` (`id_admin`, `username`, `password`, `admin_status`) VALUES
(1, 'webmysqli', '25f9e794323b453885f5181f1b624d0b', 1),
(2, 'huy', '11967d5e9addc5416ea9224eee0e91fc', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_baiviet`
--

CREATE TABLE `tbl_baiviet` (
  `id` int(11) NOT NULL,
  `tenbaiviet` varchar(255) NOT NULL,
  `tomtat` mediumtext NOT NULL,
  `noidung` longtext NOT NULL,
  `id_danhmuc` int(11) NOT NULL,
  `tinhtrang` int(11) NOT NULL,
  `hinhanh` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `id_cart` int(11) NOT NULL,
  `id_khachhang` int(11) NOT NULL,
  `code_cart` varchar(10) NOT NULL,
  `cart_status` int(11) NOT NULL,
  `cart_date` varchar(50) NOT NULL,
  `cart_payment` varchar(11) NOT NULL,
  `cart_shipping` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `tbl_cart`
--

INSERT INTO `tbl_cart` (`id_cart`, `id_khachhang`, `code_cart`, `cart_status`, `cart_date`, `cart_payment`, `cart_shipping`) VALUES
(52, 14, '18', 0, '2023-04-06 15:51:24', 'tienmat', 6),
(53, 14, '8512', 0, '2023-04-06 16:57:53', 'chuyenkhoan', 6),
(54, 14, '9540', 0, '2023-04-06 20:36:35', 'tienmat', 6),
(55, 14, '5367', 0, '2023-04-06 20:40:40', 'tienmat', 6),
(56, 14, '6091', 0, '2023-04-06 20:43:38', 'tienmat', 6),
(57, 14, '8928', 0, '2023-04-06 20:46:36', 'tienmat', 6),
(58, 15, '6517', 0, '2023-04-06 22:21:00', 'tienmat', 7),
(59, 14, '5166', 0, '2023-04-06 22:57:42', 'tienmat', 6),
(60, 14, '7509', 0, '2023-04-09 09:31:10', 'tienmat', 6),
(61, 13, '7260', 0, '2023-04-13 10:17:24', 'tienmat', 5),
(62, 13, '4541', 0, '2023-04-13 10:18:25', 'tienmat', 5),
(63, 13, '7534', 0, '2023-04-13 12:30:11', 'tienmat', 5),
(64, 13, '3281', 0, '2023-04-13 16:04:37', 'chuyenkhoan', 5);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_cart_details`
--

CREATE TABLE `tbl_cart_details` (
  `id_cart_details` int(11) NOT NULL,
  `code_cart` varchar(10) NOT NULL,
  `id_sanpham` int(11) NOT NULL,
  `soluongmua` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `tbl_cart_details`
--

INSERT INTO `tbl_cart_details` (`id_cart_details`, `code_cart`, `id_sanpham`, `soluongmua`) VALUES
(54, '1048', 12, 1),
(55, '6315', 12, 1),
(56, '4559', 12, 1),
(57, '9554', 12, 1),
(58, '2844', 12, 1),
(59, '9487', 12, 1),
(60, '3066', 12, 1),
(61, '6962', 12, 1),
(62, '6140', 12, 1),
(63, '3872', 12, 1),
(64, '1161', 7, 1),
(65, '1323', 8, 2),
(66, '1323', 6, 3),
(67, '1323', 11, 2),
(68, '7302', 27, 1),
(69, '18', 23, 1),
(70, '8512', 27, 1),
(71, '8512', 22, 1),
(72, '9540', 31, 1),
(73, '5367', 31, 1),
(74, '6091', 31, 1),
(75, '8928', 31, 1),
(76, '6517', 31, 1),
(77, '6517', 24, 1),
(78, '5166', 31, 1),
(79, '5166', 24, 1),
(80, '5166', 26, 1),
(81, '7509', 27, 1),
(82, '7260', 27, 1),
(83, '4541', 27, 6),
(84, '7534', 31, 1),
(85, '3281', 21, 2),
(86, '3281', 20, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_dangky`
--

CREATE TABLE `tbl_dangky` (
  `id_dangky` int(11) NOT NULL,
  `tenkhachhang` varchar(200) NOT NULL,
  `email` varchar(100) NOT NULL,
  `diachi` varchar(200) NOT NULL,
  `matkhau` varchar(100) NOT NULL,
  `dienthoai` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `tbl_dangky`
--

INSERT INTO `tbl_dangky` (`id_dangky`, `tenkhachhang`, `email`, `diachi`, `matkhau`, `dienthoai`) VALUES
(13, 'Phạm Quang Huy', 'phuy3255@gmail.com', '1234', '8d0d1f6bf4f16827f44657903b4bc7b5', '1234'),
(14, 'huy', 'huy', '123', '11967d5e9addc5416ea9224eee0e91fc', '123'),
(15, 'huy', 'huy@huy', '123', '11967d5e9addc5416ea9224eee0e91fc', '123');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_danhmuc`
--

CREATE TABLE `tbl_danhmuc` (
  `id_danhmuc` int(11) NOT NULL,
  `tendanhmuc` varchar(100) NOT NULL,
  `thutu` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `tbl_danhmuc`
--

INSERT INTO `tbl_danhmuc` (`id_danhmuc`, `tendanhmuc`, `thutu`) VALUES
(1, 'Lắp ráp', 1),
(2, 'Robot', 3),
(4, 'Phương tiện', 4),
(5, 'Sáng tạo', 5);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_danhmucbaiviet`
--

CREATE TABLE `tbl_danhmucbaiviet` (
  `id_baiviet` int(11) NOT NULL,
  `tendanhmuc_baiviet` varchar(255) NOT NULL,
  `thutu` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_lienhe`
--

CREATE TABLE `tbl_lienhe` (
  `id` int(11) NOT NULL,
  `thongtinlienhe` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `tbl_lienhe`
--

INSERT INTO `tbl_lienhe` (`id`, `thongtinlienhe`) VALUES
(1, '<p>Th&ocirc;ng tin li&ecirc;n hệ: huy</p>\r\n\r\n<p>SDT: 0392348011</p>\r\n');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_sanpham`
--

CREATE TABLE `tbl_sanpham` (
  `id_sanpham` int(11) NOT NULL,
  `tensanpham` varchar(250) NOT NULL,
  `masp` varchar(100) NOT NULL,
  `giasp` varchar(50) NOT NULL,
  `soluong` int(11) NOT NULL,
  `hinhanh` varchar(50) NOT NULL,
  `tomtat` text NOT NULL,
  `noidung` text NOT NULL,
  `tinhtrang` int(11) NOT NULL,
  `id_danhmuc` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `tbl_sanpham`
--

INSERT INTO `tbl_sanpham` (`id_sanpham`, `tensanpham`, `masp`, `giasp`, `soluong`, `hinhanh`, `tomtat`, `noidung`, `tinhtrang`, `id_danhmuc`) VALUES
(13, 'Lamborghini', '00003', '360000', 10, '1680152047_1679474950_pt3.jpeg', '', '<p>1. Xe đồ chơi điều khiển Rastar được mua bản quyền sử dụng từ ch&iacute;nh h&atilde;ng xe Lamborghini danh tiếng thế giới</p>\r\n\r\n<p>2. L&agrave; phi&ecirc;n bản thu nhỏ tỉ lệ 1:24 từ si&ecirc;u xe Lamborghini Superleggera với c&aacute;c đường n&eacute;t v&agrave; chi tiết sắc sảo nhất</p>\r\n\r\n<p>3. Được sản xuất với c&ocirc;ng nghệ ti&ecirc;n tiến dưới sự gi&aacute;m s&aacute;t của đội ngũ kỹ thuật vi&ecirc;n từ ch&iacute;nh h&atilde;ng xe Lamborghini cử đến</p>\r\n\r\n<p>4. Tay cầm điều khiển vừa tay, dễ thao t&aacute;c</p>\r\n\r\n<p>5. Chức năng: tiến, l&ugrave;i, tr&aacute;i, phải</p>\r\n\r\n<p>6. Đồ chơi điều khiển bảo đảm an to&agrave;n cho trẻ hoặc l&agrave; m&oacute;n qu&agrave; tuyệt vời với bao b&igrave; sang trọng</p>\r\n', 1, 4),
(14, 'Xe điều khiển', '00002', '130000', 11, '1680152309_1679474735_pt2.jpeg', '<p>00002</p>\r\n', '<p>Si&ecirc;u xe giận dữ - Bứt ph&aacute; mọi định l&yacute;</p>\r\n\r\n<p>Cuồng bạo v&agrave; dữ dội, ấn tượng v&agrave; kh&aacute;c biệt. Bạn đ&atilde; sẵn s&agrave;ng đ&oacute;n nhận cơn thịnh nộ của Si&ecirc;u xe giận dữ - Angry stunt car chưa?</p>\r\n\r\n<p>- Dựng đứng một g&oacute;c 90 độ như một t&ecirc;n lửa</p>\r\n\r\n<p>- Khả năng tăng tốc đ&aacute;ng kinh ngạc</p>\r\n\r\n<p>- Xoay v&ograve;ng 360 độ kết hợp c&ugrave;ng hiệu ứng đ&egrave;n cực cool</p>\r\n', 1, 4),
(15, 'Xe trộn xi-măng', '00001', '780000', 11, '1680152403_1679474656_pt1.jpeg', '<p><strong>Bộ sản phẩm bao xe trộn Xi măng điều khiển từ xa</strong>&nbsp;gồm:</p>\r\n\r\n<p>1 x Xe điều khiển</p>\r\n\r\n<p>1 x Remote điều khiển (x&agrave;i pin tiểu, kh&ocirc;ng k&egrave;m pin)</p>\r\n\r\n<p>1 x C&aacute;p sạc USB</p>\r\n\r\n<p>1 x Pin sạc</p>\r\n', '<h2>Đồ Chơi VECTO Xe Trộn Xi-Măng Điều Khiển Từ Xa VT2801-1</h2>\r\n\r\n<p>Bộ sưu tập xe điều khiển chủ đề xe c&ocirc;ng tr&igrave;nh- Xe trộn Xi-măng</p>\r\n\r\n<p>L&agrave; d&ograve;ng&nbsp;<strong>xe trộn Xi măng điều khiển từ xa</strong>&nbsp;được thiết kế m&ocirc; phỏng dựa tr&ecirc;n xe trộn xi-măng ngo&agrave;i đời thật. Chưa dừng lại ở đ&oacute;, xe c&ograve;n được t&iacute;ch hợp chức năng:</p>\r\n\r\n<p>- Xoay v&ograve;ng bồn trộn bằng remote điều khiển cực kỳ th&uacute; vị.</p>\r\n\r\n<p>- Hệ thống đ&egrave;n Led ph&aacute;t s&aacute;ng cực kỳ độc đ&aacute;o mỗi khi xe di chuyển hay khi thực hiện h&agrave;nh động trộn xi-măng.</p>\r\n\r\n<p>Hứa hẹn sẽ l&agrave; một m&oacute;n đồ chơi kh&ocirc;ng thể thiếu cho bộ sưu tập xe của c&aacute;c b&eacute; trai năng động.</p>\r\n', 1, 4),
(16, 'Xe vượt địa hình', '00004', '135000', 11, '1680152500_1679474494_xedk3.jpeg', '<p><strong>Bộ sản phẩm Xe vượt địa h&igrave;nh thế hệ mới bao gồm:</strong></p>\r\n\r\n<p>1 x Xe điều khiển (sử dụng pin sạc/ c&oacute; đi k&egrave;m)</p>\r\n\r\n<p>1 x Remote điều khiển (Sử dụng pin tiểu/ kh&ocirc;ng đi k&egrave;m)</p>\r\n\r\n<p>1 x C&aacute;p sạc USB</p>\r\n', '<h2>Đồ Chơi VECTO Xe Vượt Địa H&igrave;nh Thế Hệ Mới (Xanh L&aacute;) VT1918/GR</h2>\r\n\r\n<p>L&agrave; phi&ecirc;n bản n&acirc;ng cấp của c&aacute;c mẫu xe vượt địa h&igrave;nh điều khiển từ xa trước đ&acirc;y. Xe vượt địa h&igrave;nh thế hệ mới được cải tiến cả từ b&ecirc;n ngo&agrave;i lẫn b&ecirc;n trong, tạo n&ecirc;n một phi&ecirc;n bản ho&agrave;n hảo m&agrave; b&eacute; trai n&agrave;o cũng muốn sở hữu cho m&igrave;nh một chiếc.</p>\r\n\r\n<p>- Vẻ ngo&agrave;i độc đ&aacute;o với c&aacute;c đường n&eacute;t được cắt dọc th&acirc;n xe một c&aacute;ch mạnh mẽ, kết hợp c&ugrave;ng phong c&aacute;ch phối m&agrave;u theo trường ph&aacute;i hiện đại tạo n&ecirc;n một vẻ ngoại quan độc nhất, m&agrave; kh&oacute; c&oacute; d&ograve;ng xe n&agrave;o tr&ecirc;n thị trường sở hữu được.</p>\r\n\r\n<p>- Chưa dừng lại ở đ&oacute;, với hệ thống c&ocirc;ng nghệ t&acirc;n tiến b&ecirc;n trong gi&uacute;p xe di chuyển v&ocirc; c&ugrave;ng mượt m&agrave; khi b&eacute; điều khiển. Chắc chắn gi&uacute;p b&eacute; dễ d&agrave;ng chinh phục mọi địa h&igrave;nh tr&ecirc;n đường đua.</p>\r\n', 1, 4),
(17, 'Siêu Xe Koenigsegg Jesko', '003', '340000', 11, '1680152583_1679474355_lr3.jpeg', '<p>&bull; Bản sao LEGO Speed Champions 76900 Si&ecirc;u Xe Koenigsegg Jesko (280 chi tiết) ngoạn mục n&agrave;y được đ&oacute;ng g&oacute;i với c&aacute;c chi tiết ch&acirc;n thực. Một bộ kịch ho&agrave;n hảo cho những ai y&ecirc;u th&iacute;ch đồ chơi xe thể thao th&uacute; vị v&agrave; h&agrave;nh động đua gay cấn.</p>\r\n\r\n<p>&bull; C&oacute; c&aacute;i g&igrave; trong hộp vậy? Mọi thứ bạn cần để x&acirc;y dựng một m&ocirc; h&igrave;nh Koenigsegg Jesko ấn tượng, cộng với một tay đua Koenigsegg.</p>\r\n\r\n<p>&bull; Trẻ em c&oacute; thể kh&aacute;m ph&aacute; trang điểm của si&ecirc;u xe Koenigsegg Jesko ngo&agrave;i đời thực khi ch&uacute;ng chế tạo bản sao thực tế n&agrave;y, trước khi trưng b&agrave;y hoặc tham gia c&ugrave;ng bạn b&egrave; tham gia c&aacute;c cuộc đua Speed ​​Champions th&uacute; vị.</p>\r\n\r\n<p>&bull; Bộ đồ chơi m&ocirc; h&igrave;nh LEGO&reg; Speed ​​Champions 280 mảnh n&agrave;y sẽ l&agrave; m&oacute;n qu&agrave; sinh nhật tuyệt vời hoặc bất kỳ ng&agrave;y n&agrave;o kh&aacute;c d&agrave;nh cho c&aacute;c b&eacute; trai v&agrave; b&eacute; g&aacute;i từ 7 tuổi trở l&ecirc;n v&agrave; cho những ai c&oacute; niềm đam m&ecirc; với những chiếc &ocirc; t&ocirc; s&agrave;nh điệu.</p>\r\n\r\n<p>&bull; Bản sao Koenigsegg Jesko n&agrave;y c&oacute; k&iacute;ch thước cao hơn 1,5 inch (4cm), d&agrave;i 6 inch (15cm) v&agrave; rộng 2,5 inch (7cm). V&agrave;, với khung 8-stud rộng hơn, c&oacute; chỗ cho 2 nh&acirc;n vật nhỏ v&agrave; thậm ch&iacute; c&ograve;n c&oacute; nhiều chi tiết ch&acirc;n thực hơn.</p>\r\n\r\n<p>&bull; Kh&ocirc;ng cần pin cho bộ chơi &ocirc; t&ocirc; đồ chơi n&agrave;y. N&oacute; được hỗ trợ bởi tr&iacute; tưởng tượng của trẻ em - v&igrave; vậy, h&agrave;nh động đua xe kh&ocirc;ng bao giờ dừng lại!</p>\r\n\r\n<p>&bull; Mua bộ n&agrave;y cho người mới sử dụng LEGO&reg;? Kh&ocirc;ng th&agrave;nh vấn đề&hellip; n&oacute; đi k&egrave;m với c&aacute;c hướng dẫn x&acirc;y dựng từng bước, dễ l&agrave;m theo.</p>\r\n', '<p>Trẻ em v&agrave; những người đam m&ecirc; &ocirc; t&ocirc; sẽ th&iacute;ch LEGO Speed Champions 76900 Si&ecirc;u Xe Koenigsegg Jesko (280 chi tiết). Đồ chơi m&ocirc; phỏng chi tiết n&agrave;y thể hiện bản chất của si&ecirc;u xe Thụy Điển ngo&agrave;i đời thực với thiết kế kh&iacute; động học ti&ecirc;n tiến gi&uacute;p mang lại hiệu suất vượt trội 300 dặm / giờ. Trẻ em c&oacute; thể kh&aacute;m ph&aacute; chiếc xe khi họ chế tạo, trước khi đưa n&oacute; l&ecirc;n trưng b&agrave;y hoặc tham gia đường đua để c&oacute; những pha h&agrave;nh động gay cấn. Mẫu xe sưu tập n&agrave;y đi k&egrave;m với khung gầm rộng, cho ph&eacute;p đủ chỗ cho khoang l&aacute;i 2 chỗ ngồi v&agrave; thậm ch&iacute; c&ograve;n c&oacute; nhiều chi tiết ch&acirc;n thực hơn. V&agrave; với một minifigure người l&aacute;i xe Koenigsegg ho&agrave;n chỉnh với bộ đồ đua, mũ bảo hiểm v&agrave; cờ l&ecirc;, bạn sẽ c&oacute; rất nhiều cảm hứng để chơi theo tr&iacute; tưởng tượng. LEGO Speed ​​Champions s mang đến cho trẻ em v&agrave; những người h&acirc;m mộ &ocirc; t&ocirc; cơ hội thu thập v&agrave; chế tạo c&aacute;c phi&ecirc;n bản nhỏ của những chiếc &ocirc; t&ocirc; nổi tiếng v&agrave; h&agrave;ng đầu thế giới. Ho&agrave;n hảo để trưng b&agrave;y, những chiếc xe n&agrave;y cũng rất tuyệt vời để thực hiện c&aacute;c pha đua xe gay cấn với c&aacute;c loại xe kh&aacute;c trong phạm vi Speed ​​Champions.</p>\r\n', 1, 1),
(18, 'Tòa Tháp Chọc Trời', '002', '273000', 11, '1680152646_1679474259_lr2.jpeg', '<p>&bull; LEGO Minecraft 21173 T&ograve;a Th&aacute;p Chọc Trời (565 chi tiết) kết hợp nhiều loại m&ocirc;i trường c&oacute; thể x&acirc;y dựng kh&aacute;c nhau, c&oacute; thể cấu h&igrave;nh lại theo những c&aacute;ch v&ocirc; hạn để truyền cảm hứng cho những cuộc phi&ecirc;u lưu kh&ocirc;ng bao giờ kết th&uacute;c của Minecraft.</p>\r\n\r\n<p>&bull; Bao gồm h&igrave;nh Phi c&ocirc;ng với đ&ocirc;i c&aacute;nh elytra, mũ bảo hiểm netherite, 2 chiếc Phantom bay; một con m&egrave;o mướp m&agrave;u cam; v&agrave; rất nhiều phụ kiện đ&iacute;ch thực.</p>\r\n\r\n<p>&bull; Bộ đ&oacute;ng kịch linh hoạt tuyệt vời n&agrave;y khuyến kh&iacute;ch trẻ em li&ecirc;n tục điều chỉnh c&aacute;c s&aacute;ng tạo của m&igrave;nh v&agrave; kh&aacute;m ph&aacute; những cuộc phi&ecirc;u lưu mới. N&oacute; giống như tr&ograve; chơi điện tử, nhưng với c&aacute;ch x&acirc;y dựng thực h&agrave;nh v&agrave; s&aacute;ng tạo.</p>\r\n\r\n<p>&bull; Người chơi Minecraft &trade; v&agrave; những nh&agrave; x&acirc;y dựng s&aacute;ng tạo từ 8 tuổi trở l&ecirc;n sẽ tận hưởng niềm vui đắm ch&igrave;m, thực h&agrave;nh v&ocirc; tận với bộ kịch truyền cảm hứng tr&iacute; tưởng tượng n&agrave;y.</p>\r\n\r\n<p>&bull; C&oacute; k&iacute;ch thước cao hơn 7 inch (18 cm), rộng 6 inch (15 cm) v&agrave; s&acirc;u 5 inch (12 cm), bộ c&oacute; thể cấu h&igrave;nh lại n&agrave;y l&yacute; tưởng để chơi theo tr&iacute; tưởng tượng, hiển thị s&aacute;ng tạo v&agrave; kết hợp với c&aacute;c bộ LEGO&reg; Minecraft &trade; kh&aacute;c .</p>\r\n\r\n<p>&bull; Bộ kịch đầy m&agrave;u sắc chứa nhiều phụ kiện Minecraft &trade; đ&iacute;ch thực, bao gồm b&agrave;n chế t&aacute;c, đe, đ&aacute; m&agrave;i, đ&egrave;n lồng linh hồn, khoai t&acirc;y, củ dền v&agrave; một th&ugrave;ng c&aacute;.</p>\r\n', '<p>LEGO Minecraft 21173 T&ograve;a Th&aacute;p Chọc Trời (565 chi tiết) chứa đầy những pha h&agrave;nh động ch&acirc;n thực v&agrave; m&ocirc;i trường đa dạng m&agrave; trẻ em đam m&ecirc; Minecraft c&oacute; thể cấu h&igrave;nh lại nhiều lần để c&oacute; những chuyến phi&ecirc;u lưu bất tận tr&ecirc;n m&acirc;y. Trẻ em sử dụng c&aacute;c t&iacute;nh năng th&uacute; vị, đ&iacute;ch thực của Minecraft để bay l&ecirc;n trời v&agrave; x&acirc;y dựng một ng&ocirc;i nh&agrave; của thợ r&egrave;n, một t&ograve;a th&aacute;p cao v&uacute;t v&agrave; một h&ograve;n đảo trong vườn. C&aacute;c khả năng chơi bao gồm từ trồng rau cho đến chiến đấu với những b&oacute;ng ma bay. Bộ m&ocirc; h&igrave;nh mang đến cho trẻ em những khả năng x&acirc;y dựng v&agrave; s&aacute;ng tạo bất tận.</p>\r\n', 1, 1),
(19, 'Chuồng Ngựa', '001', '179000', 11, '1680152714_1679474143_lr1.jpeg', '<p>&bull; Khi trẻ sắp xếp lại v&agrave; x&acirc;y dựng lại LEGO Minecraft 21171 Chuồng Ngựa (241 chi tiết), ch&uacute;ng sẽ kh&aacute;m ph&aacute; khả năng chơi v&ocirc; tận để thưởng thức với c&aacute;c nh&acirc;n vật Minecraft quen thuộc.</p>\r\n\r\n<p>&bull; Trẻ em y&ecirc;u th&iacute;ch Minecraft &trade; sẽ nhận ra đ&aacute;m ngựa của tr&ograve; chơi trực tuyến, t&ograve;a nh&agrave; ổn định v&agrave; c&aacute;c phụ kiện Minecraft đ&iacute;ch thực tạo cảm hứng cho phần lớn tr&ograve; chơi thực h&agrave;nh.</p>\r\n\r\n<p>&bull; C&oacute; rất nhiều kiểu nhập vai để thưởng thức với bộ kịch đa năng n&agrave;y. Trẻ em c&oacute; thể cho ngựa ăn v&agrave; chăm s&oacute;c ngựa, x&acirc;y dựng chướng ngại vật để ch&uacute;ng nhảy qua v&agrave; chiến đấu với kỵ sĩ bộ xương!</p>\r\n\r\n<p>&bull; Tr&ograve; ​​chơi giải tr&iacute; trực tuyến phổ biến n&agrave;y sẽ l&agrave;m h&agrave;i l&ograve;ng người chơi Minecraft &trade; v&agrave; những người y&ecirc;u th&iacute;ch ngựa, từ 8 tuổi trở l&ecirc;n.</p>\r\n\r\n<p>&bull; C&oacute; k&iacute;ch thước cao hơn 3,5 inch (9 cm), rộng 5,5 inch (14 cm) v&agrave; s&acirc;u 5,5 inch (14 cm), bộ c&oacute; thể cấu h&igrave;nh lại n&agrave;y ho&agrave;n hảo để chơi, hiển thị v&agrave; kết hợp với c&aacute;c bộ LEGO&reg; Minecraft &trade; kh&aacute;c.</p>\r\n\r\n<p>&bull; Bộ chơi LEGO&reg; Minecraft &trade; mang đến cho người chơi Minecraft một c&aacute;ch mới để thưởng thức tr&ograve; chơi y&ecirc;u th&iacute;ch của họ, với c&aacute;c nh&acirc;n vật, cảnh v&agrave; t&iacute;nh năng được l&agrave;m sống động bằng sự kết hợp gi&agrave;u tr&iacute; tưởng tượng của c&aacute;c khối LEGO.</p>\r\n', '<p>LEGO Minecraft 21171 Chuồng Ngựa (241 chi tiết) kết hợp tất cả niềm vui v&agrave; cuộc phi&ecirc;u lưu của tr&ograve; chơi trực tuyến phổ biến với khả năng s&aacute;ng tạo v&ocirc; tận của những vi&ecirc;n gạch LEGO v&agrave; niềm vui khi chăm s&oacute;c những ch&uacute; ngựa. Những đứa trẻ th&iacute;ch s&aacute;ng tạo sẽ th&iacute;ch bộ LEGO Minecraft đa năng n&agrave;y. Chuồng c&oacute; cửa mở v&agrave; chứa đầy c&aacute;c chi tiết Minecraft đ&iacute;ch thực, chẳng hạn như c&agrave; rốt v&agrave;ng v&agrave; &aacute;o gi&aacute;p qu&yacute; gi&aacute;. C&oacute; những con ngựa để nu&ocirc;i v&agrave; chăm s&oacute;c, một chướng ngại vật để thiết kế v&agrave; một bộ xương kỵ sĩ để chiến đấu! Bộ x&acirc;y dựng v&agrave; chơi thực h&agrave;nh, l&agrave; một m&oacute;n qu&agrave; l&yacute; tưởng cho trẻ em - những người chơi Minecraft cũng như những người y&ecirc;u th&iacute;ch ngựa.</p>\r\n', 1, 1),
(20, 'Rồng băng huyền bí', '03', '270000', 11, '1680152781_1679474041_rb3.jpeg', '<p>Sản phẩm c&oacute; c&aacute;c đặc điểm nổi bật sau:</p>\r\n\r\n<p>&bull; Robot rồng phun kh&oacute;i c&oacute; k&iacute;ch cỡ ph&ugrave; hợp gi&uacute;p b&eacute; dễ d&agrave;ng quan s&aacute;t.</p>\r\n\r\n<p>&bull; Thiết kế của ch&uacute; rồng tinh xảo đến từng chiếc vảy sừng.</p>\r\n\r\n<p>&bull; Hơn thế nữa, robot c&ograve;n c&oacute; thể điều khiển để ch&uacute; rồng di chuyển, vỗ c&aacute;nh v&agrave; phun kh&oacute;i theo &yacute; b&eacute;. Kết hợp c&ugrave;ng hiệu ứng đ&egrave;n Led v&agrave; tiếng gầm gừ chạy bằng pin l&agrave;m cho ch&uacute; rồng robot c&agrave;ng th&ecirc;m sống động.</p>\r\n\r\n<p>&bull; Sản phẩm được sản xuất bằng c&ocirc;ng nghệ ti&ecirc;n tiến, sử dụng chất liệu cao cấp c&ugrave;ng m&agrave;u sơn bền đẹp, chắc chắn, an to&agrave;n tuyệt đối với sức khỏe của trẻ em.</p>\r\n', '<p>Rồng phun kh&oacute;i - 1303004301 của thương hiệu DISCOVERY #MINDBLOWN với khả năng phun kh&oacute;i độc đ&aacute;o. Ch&uacute; rồng sở hữu 2 tiếng gầm thể hiện hai trạng th&aacute;i tấn c&ocirc;ng v&agrave; ph&ograve;ng thủ t&aacute;ch biệt. Với mỗi bước đi đầy uy nghi&ecirc;m, ch&uacute; rồng sẽ vỗ đ&ocirc;i c&aacute;nh mạnh mẽ, v&agrave; đ&ocirc;i mắt sẽ s&aacute;ng l&ecirc;n như tia chớp. B&eacute; sẽ được điều khiển ch&uacute; rồng dũng m&atilde;nh n&agrave;y di chuyển tiến, l&ugrave;i, v&agrave; tr&aacute;i, phải. Với từng khớp chuyển động như thật, b&eacute; sẽ cảm nhận được sự mạnh mẽ trong từng động t&aacute;c của ch&uacute; r&ocirc;ng phun kh&oacute;i n&agrave;y.</p>\r\n', 1, 1),
(21, 'Robot biến hình', '02', '560000', 11, '1680152885_1679473865_rb2.jpeg', '<p><strong>Bộ sản phẩm robot biến h&igrave;nh Strike</strong>&nbsp;bao gồm:</p>\r\n\r\n<p>1 x Robot Strike (C&oacute; k&egrave;m pin sạc b&ecirc;n trong)</p>\r\n\r\n<p>1 x Remote điều khiển (x&agrave;i pin tiểu kh&ocirc;ng k&egrave;m pin)</p>\r\n\r\n<p>1 x C&aacute;p sạc USB</p>\r\n', '<h2>Đồ Chơi VECTO Robot Biến H&igrave;nh Điều Khiển Từ Xa Strike VTK4</h2>\r\n\r\n<p>Robot biến h&igrave;nh điều khiển từ xa STRIKE được thiết kế v&ocirc; c&ugrave;ng ấn tượng với c&aacute;c đường n&eacute;t g&oacute;c cạnh tạo n&ecirc;n sự mạnh mẽ, uy nghi&ecirc;m của một chiến binh. V&agrave; được t&iacute;ch hợp c&aacute;c t&iacute;nh năng si&ecirc;u việt sẵn s&agrave;ng để chống lại thế lực x&acirc;m lược hư kh&ocirc;ng.</p>\r\n\r\n<p>- Khả năng thay đổi h&igrave;nh dạng ấn tượng</p>\r\n\r\n<p>- Biến h&igrave;nh chỉ với 1 c&uacute; chạm tay</p>\r\n\r\n<p>- Lập tr&igrave;nh một chuỗi h&agrave;nh động độc đ&aacute;o</p>\r\n\r\n<p>- Ng&ocirc;n ngữ Robot ấn tượng c&ugrave;ng khả năng nhảy m&uacute;a theo nhạc si&ecirc;u cool</p>\r\n', 1, 2),
(22, 'Robot chú chó tinh nghịch', '01', '350000', 11, '1680153054_1679473757_rb1.jpeg', '<p><strong>Bộ sản phẩm bao Robot ch&uacute; ch&oacute; tinh nghịch</strong>&nbsp;gồm:</p>\r\n\r\n<p>1 x Robot ch&uacute; ch&oacute; tinh nghịch (c&oacute; k&egrave;m pin sạc b&ecirc;n trong)</p>\r\n\r\n<p>1 x Remote điều khiển (x&agrave;i pin tiểu Kh&ocirc;ng k&egrave;m pin)</p>\r\n', '<h2>Đồ Chơi VECTO Robot Ch&uacute; Ch&oacute; Tinh Nghịch - N&ocirc; Đ&ugrave;a C&ugrave;ng B&eacute; VT18012</h2>\r\n\r\n<p>Dễ thương v&agrave; l&eacute;m lỉnh, tinh nghịch nhưng đầy th&aacute;o v&aacute;t. Robot ch&uacute; ch&oacute; tinh nghịch đ&atilde; đến rồi đ&acirc;y. C&aacute;c b&eacute; v&agrave; ba mẹ đ&atilde; sẵn s&agrave;ng rước ch&uacute; về chưa n&egrave;?</p>\r\n\r\n<p>- Khả năng sủa giống hệt ch&oacute; thật</p>\r\n\r\n<p>- Nhảy m&uacute;a theo nhạc cực Cool</p>\r\n\r\n<p>- Chức năng lập tr&igrave;nh một chuỗi động t&aacute;c độc đ&aacute;o</p>\r\n\r\n<p>- Điều khiển linh hoạt tới, lui, tr&aacute;i , phải</p>\r\n\r\n<p>Ngo&agrave;i c&aacute;c chức năng nổi trội tr&ecirc;n với thiết kế vẻ mặt cực kỳ dễ thương nhưng kh&ocirc;ng k&eacute;m phần nghịch ngợm sẽ gi&uacute;p cho c&aacute;c gi&acirc;y ph&uacute;t vui chơi của b&eacute; v&ocirc; c&ugrave;ng h&agrave;o hứng.</p>\r\n', 1, 2),
(23, 'Truy tìm khủng long', '6', '333000', 11, '1680153126_1679473581_st6.jpeg', '<p><strong>* Sản phẩm gồm:</strong><br />\r\n_1 phiến đ&aacute; lớn<br />\r\n_ 1 b&uacute;a gỗ v&agrave; 1 đục gỗ để đục phiến đ&aacute;<br />\r\n_ 1 cọ để qu&eacute;t sạch bụi b&aacute;m tr&ecirc;n xương khủng long<br />\r\n_ 1 Hướng dẫn sử dụng<br />\r\n_ 1 Th&ocirc;ng tin khoa học th&uacute; vị kh&aacute;c hoặc hướng dẫn thực nghiệm khoa học ứng dụng kh&aacute;c k&egrave;m theo.<br />\r\n<strong>* Hướng dẫn c&aacute;ch chơi:</strong><br />\r\n_D&ugrave;ng nước ng&acirc;m mềm phiến đ&aacute;, để c&oacute; thể đục phiến đ&aacute; dẽ d&agrave;ng hơn.</p>\r\n', '<p>Đồ chơi khoa học STEAM h&agrave;ng đầu nước Mỹ của nh&atilde;n h&agrave;ng&nbsp;<strong>DISCOVERY #MINDBLOWN</strong>, hợp t&aacute;c c&ugrave;ng k&ecirc;nh truyền h&igrave;nh nổi tiếng DISCOVERY, đem lại cho b&eacute; những trải nghiệm khoa học ứng dụng vừa học, vừa chơi.<br />\r\nCho đến hiện nay, con người chỉ mới ph&aacute;t hiện được h&oacute;a thạch của hơn 700 lo&agrave;i khủng long kh&aacute;c nhau đ&atilde; tuyệt chủng.&nbsp;<strong>BỘ KHẢO CỔ TRUY T&Igrave;M XƯƠNG KHỦNG LONG - VELOCIRAPTOR</strong>&nbsp;cho b&eacute; trải nghiệm khảo cổ v&agrave; khai quật để t&igrave;m ra vết t&iacute;ch của lo&agrave;i khủng long đ&atilde; tiệt chủng.<br />\r\n- Vừa chơi, vừa kh&aacute;m ph&aacute; những điều b&iacute; ẩn của lo&agrave;i Khủng long đ&atilde; tuyệt chủng. V&agrave; sưu tập bộ xương khủng long ẩn s&acirc;u trong phiến đ&aacute;.</p>\r\n', 1, 5),
(24, 'Cát động lực', '5', '89000', 11, '1680153203_1679473507_st5.jpeg', '<h2>Đồ Chơi KINETIC SAND C&aacute;t Động Lực - Kem Ly 2 Vị Ngọt Ng&agrave;o&nbsp;6058757 - Giao h&agrave;ng ngẫu nhi&ecirc;n</h2>\r\n\r\n<p>C&aacute;t động lực Kinetic Sand l&agrave; thương hiệu đến từ Canada, được sản xuất ở Ph&aacute;p. C&aacute;t của Kinetic Sand được l&agrave;m từ c&aacute;c nguy&ecirc;n liệu tự nhi&ecirc;n đảm bảo an to&agrave;n, kh&ocirc;ng bị kh&ocirc;, kh&ocirc;ng bị d&iacute;nh tay, dễ d&agrave;ng vệ sinh.</p>\r\n\r\n<p>Trong mỗi sản phẩm c&aacute;t động lực &ndash; Kem ly 2 vị c&oacute; chứa 113g c&aacute;t c&oacute; m&ugrave;i hương chia l&agrave;m 2 m&ugrave;i vị giống như que kem m&aacute;t lạnh.</p>\r\n\r\n<p>C&oacute; 2 m&ugrave;i cho b&eacute; lựa chọn: Socola bạc h&agrave; hoặc D&acirc;u chuối.</p>\r\n', '<p><strong>C&aacute;ch chơi:</strong>&nbsp;Sử dụng muỗng c&oacute; sẵn để tạo h&igrave;nh que kem. B&eacute; c&oacute; thể thỏa th&iacute;ch kết hợp để tạo ra c&aacute;c m&agrave;u mới.</p>\r\n\r\n<p>C&aacute;t động lực Kinetic Sand c&oacute; lớp keo đặc biệt gi&uacute;p dễ d&agrave;ng tạo h&igrave;nh &nbsp;</p>\r\n\r\n<p>Sản phẩm ph&ugrave; hợp cho b&eacute; từ 3 tuổi trở l&ecirc;n.</p>\r\n', 1, 5),
(25, 'Bộ nha sĩ mini', '4', '249000', 11, '1680153296_1679467024_st4.jpeg', '<h2>Đồ Chơi PLAYDOH Bộ Nha Sĩ Mini E4919</h2>\r\n\r\n<p>Đồ chơi bột nặn Play Doh bộ nha sĩ mini E4919 l&agrave; bộ đồ chơi đất nặn ho&agrave;n hảo cho sự trải nghiệm l&agrave;m nha sĩ của b&eacute;. Ph&aacute;t huy tr&iacute; tưởng tượng của trẻ với đầy đủ dụng cụ nha khoa như thật : khu&ocirc;n răng, m&aacute;y khoan,b&agrave;n chải, nh&acirc;n vật h&igrave;nh người, k&egrave;m theo 2 lon &ldquo;Hợp Chất&rdquo; vệ sinh răng miệng của Play Doh.</p>\r\n', '<p>Đồ chơi Nha Sĩ Mini theo chủ đề Play Doh cổ điển đ&atilde; tạo n&ecirc;n nụ cười cho nhiều thế hệ, phi&ecirc;n bản n&agrave;y nhỏ gọn v&agrave; dễ d&agrave;ng hơn khi lưu giữ hoặc di chuyển,<br />\r\nĐồ chơi bột nặn Play Doh Bộ Nha Sĩ Mini c&oacute; c&aacute;c đặc điểm nổi bật sau :<br />\r\nBột nặn được l&agrave;m ho&agrave;n to&agrave;n bằng nguy&ecirc;n liệu tự nhi&ecirc;n, l&agrave;nh t&iacute;nh với da của b&eacute;, phụ huynh ho&agrave;n to&agrave;n y&ecirc;n t&acirc;m khi cho b&eacute; vui chơi l&acirc;u d&agrave;i<br />\r\nTừng khu&ocirc;n răng, dụng cụ y khoa được nghi&ecirc;n cứu kỹ lưỡng, bo đều c&aacute;c g&oacute;c, an to&agrave;n cho b&agrave;n tay nhỏ của b&eacute;<br />\r\nM&agrave;u sắc đa dạng, sinh động, c&oacute; thể s&aacute;ng tạo trộn c&aacute;c m&agrave;u với nhau để tạo th&agrave;nh m&agrave;u mới.<br />\r\nK&iacute;ch th&iacute;ch s&aacute;ng tạo, truyền cảm hứng thực h&agrave;nh m&ocirc; phỏng qu&aacute; tr&igrave;nh kh&aacute;m bệnh, ph&aacute;t triển tư duy nhận dạng, gi&uacute;p b&eacute; vui chơi thoải m&aacute;i lại vừa được học hỏi .</p>\r\n', 1, 5),
(26, 'Hạt tạo hình PixoBitz', '3', '150000', 10, '1680153380_1679466457_st3.jpeg', '<p><strong>Bộ sản phẩm bao gồm:</strong></p>\r\n\r\n<p>-&nbsp;522 hạt tạo h&igrave;nh với 16 m&agrave;u</p>\r\n\r\n<p>-&nbsp;6 phụ kiện</p>\r\n\r\n<p>-&nbsp;Miếng trang tr&iacute;</p>\r\n\r\n<p>-&nbsp;1 b&igrave;nh xịt</p>\r\n\r\n<p>-&nbsp;1 khay</p>\r\n\r\n<p>-&nbsp;6 templates</p>\r\n\r\n<p>Với bộ sản phẩm tr&ecirc;n, bạn c&oacute; thể tạo ra 15 m&ocirc; h&igrave;nh độc đ&aacute;o c&oacute; một kh&ocirc;ng hai bao gồm: nh&acirc;n vật, m&egrave;o con, c&aacute; heo, v&aacute;n trượt v&agrave; nhiều m&ocirc; h&igrave;nh kh&aacute;c.</p>\r\n\r\n<p>Lưu &yacute;, h&atilde;y chờ 20 ph&uacute;t sau mỗi lớp v&agrave; 45 ph&uacute;t sau khi ho&agrave;n thiện t&aacute;c phẩm cuối c&ugrave;ng trước khi chơi để c&aacute;c hạt c&oacute; thời gian kết d&iacute;nh với nhau chắc chắn hơn.</p>\r\n\r\n<p>B&eacute; c&oacute; thể sử dụng t&aacute;c phẩm của m&igrave;nh để l&agrave;m đồ trang tr&iacute; trong ph&ograve;ng, m&oacute;c ch&igrave;a kh&oacute;a hay m&oacute;c balo.</p>\r\n', '<h2><strong>Đồ Chơi PIXOBITZ Hạt Tạo H&igrave;nh Pixobitz - Bộ Bundle 6064721</strong></h2>\r\n\r\n<p>C&ugrave;ng thỏa th&iacute;ch s&aacute;ng tạo c&ugrave;ng hạt tạo h&igrave;nh PixoBitz &ndash; thật dễ d&agrave;ng để tạo h&igrave;nh 3D v&agrave; 2D.</p>\r\n\r\n<p><strong>Kh&ocirc;ng&nbsp;</strong></p>\r\n', 1, 5),
(27, 'Thức uống phiên bản mini', '2', '149000', 11, '1680153459_1679466328_st2.jpeg', '<h2>Đồ Chơi MINIVERSE Thức Uống Phi&ecirc;n Bản Mini&nbsp;587200C3 - Giao h&agrave;ng ngẫu nhi&ecirc;n</h2>\r\n\r\n<p>Đồ chơi Miniverse l&agrave; bộ sưu tập đồ ăn mini để bạn thoả sức sưu tập, chế biến v&agrave; trưng b&agrave;y theo sở th&iacute;ch. Đặc điểm của sản phẩm:</p>\r\n\r\n<p>+ Mỗi quả b&oacute;ng l&agrave; c&aacute;c nguy&ecirc;n liệu thực tế để tạo bản sao nhỏ cho c&aacute;c m&oacute;n nước, cafe v&agrave; b&aacute;nh ngọt.</p>\r\n\r\n<p>+ Mỗi g&oacute;i l&agrave; một BẤT NGỜ n&ecirc;n bạn sẽ kh&ocirc;ng biết m&igrave;nh c&oacute; nguy&ecirc;n liệu n&agrave;o n&agrave;o cho đến khi mở hộp.</p>\r\n\r\n<p>+ Đi k&egrave;m mỗi quả b&oacute;ng l&agrave; 1 bản hướng dẫn chế biến m&oacute;n ăn.</p>\r\n\r\n<p>+ Sau khi bạn đ&atilde; tạo xong bản sao nhỏ của m&igrave;nh, h&atilde;y đặt bản sao của bạn dưới &aacute;nh s&aacute;ng ban ng&agrave;y trong khoảng 5 ph&uacute;t cho đến khi nhựa cứng lại. V&agrave; thế l&agrave; bạn đ&atilde; c&oacute; một bộ sưu tập sẵn s&agrave;ng để trưng b&agrave;y theo đ&uacute;ng sở th&iacute;ch của bản th&acirc;n rồi.</p>\r\n', '<h2>Đồ Chơi MINIVERSE Thức Uống Phi&ecirc;n Bản Mini&nbsp;587200C3 - Giao h&agrave;ng ngẫu nhi&ecirc;n</h2>\r\n\r\n<p>Đồ chơi Miniverse l&agrave; bộ sưu tập đồ ăn mini để bạn thoả sức sưu tập, chế biến v&agrave; trưng b&agrave;y theo sở th&iacute;ch. Đặc điểm của sản phẩm:</p>\r\n\r\n<p>+ Mỗi quả b&oacute;ng l&agrave; c&aacute;c nguy&ecirc;n liệu thực tế để tạo bản sao nhỏ cho c&aacute;c m&oacute;n nước, cafe v&agrave; b&aacute;nh ngọt.</p>\r\n\r\n<p>+ Mỗi g&oacute;i l&agrave; một BẤT NGỜ n&ecirc;n bạn sẽ kh&ocirc;ng biết m&igrave;nh c&oacute; nguy&ecirc;n liệu n&agrave;o n&agrave;o cho đến khi mở hộp.</p>\r\n\r\n<p>+ Đi k&egrave;m mỗi quả b&oacute;ng l&agrave; 1 bản hướng dẫn chế biến m&oacute;n ăn.</p>\r\n\r\n<p>+ Sau khi bạn đ&atilde; tạo xong bản sao nhỏ của m&igrave;nh, h&atilde;y đặt bản sao của bạn dưới &aacute;nh s&aacute;ng ban ng&agrave;y trong khoảng 5 ph&uacute;t cho đến khi nhựa cứng lại. V&agrave; thế l&agrave; bạn đ&atilde; c&oacute; một bộ sưu tập sẵn s&agrave;ng để trưng b&agrave;y theo đ&uacute;ng sở th&iacute;ch của bản th&acirc;n rồi.</p>\r\n', 1, 5);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_shipping`
--

CREATE TABLE `tbl_shipping` (
  `id_shipping` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `note` varchar(100) NOT NULL,
  `id_dangky` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `tbl_shipping`
--

INSERT INTO `tbl_shipping` (`id_shipping`, `name`, `phone`, `address`, `note`, `id_dangky`) VALUES
(5, 'huy', '123', '123', '123', 13),
(6, 'huy', '123', '123', '123', 14),
(7, 'huy', '123', '123', '123', 15);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_thongke`
--

CREATE TABLE `tbl_thongke` (
  `id` int(11) NOT NULL,
  `ngaydat` varchar(30) NOT NULL,
  `donhang` int(11) NOT NULL,
  `doanhthu` varchar(100) NOT NULL,
  `soluongban` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `tbl_thongke`
--

INSERT INTO `tbl_thongke` (`id`, `ngaydat`, `donhang`, `doanhthu`, `soluongban`) VALUES
(15, '2023-04-13', 13, '2437000', 3);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Chỉ mục cho bảng `tbl_baiviet`
--
ALTER TABLE `tbl_baiviet`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`id_cart`);

--
-- Chỉ mục cho bảng `tbl_cart_details`
--
ALTER TABLE `tbl_cart_details`
  ADD PRIMARY KEY (`id_cart_details`);

--
-- Chỉ mục cho bảng `tbl_dangky`
--
ALTER TABLE `tbl_dangky`
  ADD PRIMARY KEY (`id_dangky`);

--
-- Chỉ mục cho bảng `tbl_danhmuc`
--
ALTER TABLE `tbl_danhmuc`
  ADD PRIMARY KEY (`id_danhmuc`);

--
-- Chỉ mục cho bảng `tbl_danhmucbaiviet`
--
ALTER TABLE `tbl_danhmucbaiviet`
  ADD PRIMARY KEY (`id_baiviet`);

--
-- Chỉ mục cho bảng `tbl_lienhe`
--
ALTER TABLE `tbl_lienhe`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tbl_sanpham`
--
ALTER TABLE `tbl_sanpham`
  ADD PRIMARY KEY (`id_sanpham`);

--
-- Chỉ mục cho bảng `tbl_shipping`
--
ALTER TABLE `tbl_shipping`
  ADD PRIMARY KEY (`id_shipping`);

--
-- Chỉ mục cho bảng `tbl_thongke`
--
ALTER TABLE `tbl_thongke`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `tbl_baiviet`
--
ALTER TABLE `tbl_baiviet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `id_cart` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT cho bảng `tbl_cart_details`
--
ALTER TABLE `tbl_cart_details`
  MODIFY `id_cart_details` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT cho bảng `tbl_dangky`
--
ALTER TABLE `tbl_dangky`
  MODIFY `id_dangky` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT cho bảng `tbl_danhmuc`
--
ALTER TABLE `tbl_danhmuc`
  MODIFY `id_danhmuc` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `tbl_danhmucbaiviet`
--
ALTER TABLE `tbl_danhmucbaiviet`
  MODIFY `id_baiviet` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `tbl_lienhe`
--
ALTER TABLE `tbl_lienhe`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `tbl_sanpham`
--
ALTER TABLE `tbl_sanpham`
  MODIFY `id_sanpham` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT cho bảng `tbl_shipping`
--
ALTER TABLE `tbl_shipping`
  MODIFY `id_shipping` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT cho bảng `tbl_thongke`
--
ALTER TABLE `tbl_thongke`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
